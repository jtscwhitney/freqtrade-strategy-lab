# pragma pylint: disable=missing-docstring, invalid-name, pointless-string-statement
# flake8: noqa
"""
EnhancedCointPairsStrategy_V01 — Candidate L Phase 1: dual-leg BTC/ETH @ 4h

Phase 0: BTC/ETH@4h scored GO (6/8). This strategy hedges both legs (market-neutral
intent) vs archived single-leg CointPairs.

Spread: log(BTC) - β * log(ETH), rolling OLS β.
- z > +ENTRY: short BTC, long ETH
- z < -ENTRY: long BTC, short ETH
Exit: |z| inside EXIT band; time stop; wide emergency stoploss (primary = z-reversion).

Phase 0 fee sweep had no ATR/vol filter — crisis gate omitted here for parity with that test.
Vol filter + adaptive trailing stop: deferred (dev plan incremental steps).
"""
from __future__ import annotations

import numpy as np
import pandas as pd
from pandas import DataFrame
from datetime import datetime

from freqtrade.strategy import IStrategy, merge_informative_pair
from freqtrade.persistence import Trade


class EnhancedCointPairsStrategy_V01(IStrategy):
    INTERFACE_VERSION = 3

    timeframe = "4h"
    inf_tf = "4h"

    minimal_roi = {"0": 100}
    stoploss = -0.99
    use_custom_stoploss = False

    can_short = True
    startup_candle_count: int = 400

    # Phase 0–aligned defaults (fee sweep used 2.0 / 0.5 on validation slice)
    ENTRY_ZSCORE: float = 2.0
    EXIT_ZSCORE: float = 0.5

    OLS_WINDOW: int = 180
    ZSCORE_WINDOW: int = 84
    MAX_HOLD_CANDLES: int = 360

    _ANCHOR = "ETH/USDT:USDT"
    _TRADED = "BTC/USDT:USDT"

    def informative_pairs(self) -> list[tuple[str, str]]:
        return [
            (self._TRADED, self.inf_tf),
            (self._ANCHOR, self.inf_tf),
        ]

    def populate_indicators(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        pair = metadata["pair"]
        if pair == self._TRADED:
            other = self.dp.get_pair_dataframe(self._ANCHOR, self.inf_tf)
            if other.empty:
                return self._nan_frame(dataframe)
            other = other[["date", "close"]].rename(columns={"close": "anchor_close"})
            dataframe = merge_informative_pair(
                dataframe, other, self.timeframe, self.inf_tf,
                ffill=True, date_column="date",
            )
            acol = f"anchor_close_{self.inf_tf}"
            log_y = np.log(dataframe["close"])
            log_x = np.log(dataframe[acol])
        else:
            other = self.dp.get_pair_dataframe(self._TRADED, self.inf_tf)
            if other.empty:
                return self._nan_frame(dataframe)
            other = other[["date", "close"]].rename(columns={"close": "traded_close"})
            dataframe = merge_informative_pair(
                dataframe, other, self.timeframe, self.inf_tf,
                ffill=True, date_column="date",
            )
            tcol = f"traded_close_{self.inf_tf}"
            log_y = np.log(dataframe[tcol])
            log_x = np.log(dataframe["close"])

        dataframe["hedge_ratio"] = self._rolling_hedge_ratio(log_y, log_x, self.OLS_WINDOW)
        dataframe["spread"] = log_y - dataframe["hedge_ratio"] * log_x
        sm = dataframe["spread"].rolling(self.ZSCORE_WINDOW).mean()
        sd = dataframe["spread"].rolling(self.ZSCORE_WINDOW).std().replace(0, np.nan)
        dataframe["z_score"] = (dataframe["spread"] - sm) / sd

        return dataframe

    def _nan_frame(self, dataframe: DataFrame) -> DataFrame:
        dataframe["z_score"] = np.nan
        return dataframe

    def populate_entry_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        pair = metadata["pair"]
        ok = dataframe["z_score"].notna() & (dataframe["volume"] > 0)

        if pair == self._TRADED:
            dataframe.loc[ok & (dataframe["z_score"] < -self.ENTRY_ZSCORE), "enter_long"] = 1
            dataframe.loc[ok & (dataframe["z_score"] > self.ENTRY_ZSCORE), "enter_short"] = 1
        else:
            dataframe.loc[ok & (dataframe["z_score"] > self.ENTRY_ZSCORE), "enter_long"] = 1
            dataframe.loc[ok & (dataframe["z_score"] < -self.ENTRY_ZSCORE), "enter_short"] = 1

        return dataframe

    def populate_exit_trend(self, dataframe: DataFrame, metadata: dict) -> DataFrame:
        pair = metadata["pair"]
        has_signal = dataframe["z_score"].notna()

        if pair == self._TRADED:
            dataframe.loc[has_signal & (dataframe["z_score"] > -self.EXIT_ZSCORE), "exit_long"] = 1
            dataframe.loc[has_signal & (dataframe["z_score"] < self.EXIT_ZSCORE), "exit_short"] = 1
        else:
            dataframe.loc[has_signal & (dataframe["z_score"] < self.EXIT_ZSCORE), "exit_long"] = 1
            dataframe.loc[has_signal & (dataframe["z_score"] > -self.EXIT_ZSCORE), "exit_short"] = 1

        return dataframe

    def custom_exit(
        self,
        pair: str,
        trade: Trade,
        current_time: datetime,
        current_rate: float,
        current_profit: float,
        **kwargs,
    ) -> str | None:
        tf_sec = 4 * 3600
        trade_duration_candles = int((current_time - trade.open_date_utc).total_seconds() / tf_sec)
        if trade_duration_candles >= self.MAX_HOLD_CANDLES:
            return "time_stop"
        return None

    def leverage(
        self,
        pair: str,
        current_time: datetime,
        current_rate: float,
        proposed_leverage: float,
        max_leverage: float,
        entry_tag: str,
        side: str,
        **kwargs,
    ) -> float:
        return min(2.0, max_leverage)

    def _rolling_hedge_ratio(self, y: pd.Series, x: pd.Series, window: int) -> pd.Series:
        y_vals = y.values.astype(float)
        x_vals = x.values.astype(float)
        n = len(y_vals)
        betas = np.full(n, np.nan)
        for i in range(window - 1, n):
            y_w = y_vals[i - window + 1 : i + 1]
            x_w = x_vals[i - window + 1 : i + 1]
            if np.any(np.isnan(y_w)) or np.any(np.isnan(x_w)):
                continue
            x_mean = x_w.mean()
            y_mean = y_w.mean()
            x_demeaned = x_w - x_mean
            var_x = np.dot(x_demeaned, x_demeaned)
            if var_x < 1e-12:
                continue
            betas[i] = np.dot(x_demeaned, y_w - y_mean) / var_x
        return pd.Series(betas, index=y.index)
